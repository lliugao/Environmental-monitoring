#include "stm32f4xx.h"
#include "delay.h"
#include "sys.h"
#include "usart.h" 
#include "dqy.h" 
#include "dht11.h"
#include "pm.h"
#include "lcd.h"
extern _bmp180 bmp180;
extern u8 Res;
extern u16 flag3;
const u8 TEXT_Buffer[]={"WarShipSTM32 IIC TEST"};
#define SIZE sizeof(TEXT_Buffer)	
	

 int main(void)
 {	 			    
	u8 temperature;  	    
	u8 humidity;
	u8 ID = 0;
	 u16 tem;
	delay_init(168);	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200	 	
	uart3_init(9600);
	LCD_Init();
	POINT_COLOR=RED;//��������Ϊ��ɫ 
	LCD_ShowString(50,20,220,60,16,"Graduation project");	
	LCD_ShowString(25,50,200,30,16,"Weather conditions today:");	
	LCD_ShowString(150,280,200,16,16,"2019/5/30");
	LCD_ShowString(25,180,200,35,16,"kindly reminder:");
	printf("AT+CIPMUX=1\r\n");  
	delay_ms(300);
	printf("AT+CIPSERVER=1,8086\r\n"); 
	delay_ms(300);	 
	BMP_Init();
	BMP_ReadCalibrationData();	
	DHT11_Init();
	while(1)
	{
		printf("AT+CIPSEND=0,60\r\n"); 
		delay_ms(300);
		ID = BMP_ReadOneByte(0xd0);
		BMP_UncompemstatedToTrue();
		DHT11_Read_Data(&temperature,&humidity);		//��ȡ��ʪ��ֵ					    	   
		printf("%dK%dK%ldK",humidity,temperature,bmp180.p);
		POINT_COLOR=BLUE;//��������Ϊ��ɫ
		LCD_ShowString(25,70,200,16,16,"humidity:");
		LCD_ShowNum(120,70,humidity,4,16);
		LCD_ShowString(25,90,200,18,16,"temperature:");
		LCD_ShowNum(120,90,temperature,4,16);
		LCD_ShowString(25,110,200,16,16,"pressure:");
		LCD_ShowNum(120,110,bmp180.p,6,16);
		if(temperature>=35)
		{
			LCD_ShowString(25,220,200,16,16,"High temperature warning");
			LCD_ShowString(25,240,200,16,16,"Go out less");
		}
		else if(temperature<35&&temperature>=20)
		{
			LCD_ShowString(25,220,200,16,16,"Temperature adapation");
			LCD_ShowString(25,240,200,16,16,"wear summer clother");
		}
		else if(temperature<20&&temperature>=0)
		{
			LCD_ShowString(25,220,200,16,16,"Pay attention to cold prevention");
			LCD_ShowString(25,240,200,16,16,"wear winter clother");
		}
		else if(temperature<0)
		{
			LCD_ShowString(25,220,200,16,16,"Icing warning");
			LCD_ShowString(25,240,200,16,16,"Go out less");
		}
		if(flag3){
			

				printf("%dK\n",USART3_RX_BUF[5]);
			LCD_ShowString(25,130,200,16,16,"pm2.5:");
			if(USART3_RX_BUF[5]>=0&&USART3_RX_BUF[5]<=50)
		{
		LCD_ShowString(25,200,200,16,16,"Excellent air quality");
		}
		if(USART3_RX_BUF[5]>=51&&USART3_RX_BUF[5]<=100)
		{
		LCD_ShowString(25,200,200,16,16,"Good air quality");
		}
		if(USART3_RX_BUF[5]>=101&&USART3_RX_BUF[5]<=150)
		{
		LCD_ShowString(25,200,200,16,16,"Mild air pollution");
		}
		if(USART3_RX_BUF[5]>=151&&USART3_RX_BUF[5]<=200)
		{
		LCD_ShowString(25,200,200,16,16,"Severe air pollution");
		}
			LCD_ShowNum(120,130,USART3_RX_BUF[5],4,16);
				//USART_SendData(USART1, USART3_RX_BUF[5]);  				//�򴮿�1��������
				while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
			flag3 = 0;
		}
		delay_ms(1000);								     
	}
}
